const products = [
    { id: 1, title: "iPhone 12 Pro", description: "Como nuevo, con caja y accesorios", price: 650, category: "Electrónica", image: "https://via.placeholder.com/300", detailsUrl: "product-details.html?id=1" },
    { id: 2, title: "Sofá de piel", description: "Sofá de tres plazas en perfecto estado", price: 350, category: "Hogar", image: "https://via.placeholder.com/300", detailsUrl: "product-details.html?id=2" },
    { id: 3, title: "Bicicleta de montaña", description: "Bici profesional, usada solo 3 veces", price: 450, category: "Deportes", image: "https://via.placeholder.com/300", detailsUrl: "product-details.html?id=3" }
];

let cart = [];
let filters = { category: "all", searchQuery: "" };

function toggleCart() {
    const cartSidebar = document.getElementById("cartSidebar");
    cartSidebar.classList.toggle("visible");
}

function renderFilters() {
    const filtersContainer = document.getElementById("filters");
    filtersContainer.innerHTML = `
      <select id="categoryFilter" onchange="applyFilters()">
        <option value="all">Todas las Categorías</option>
        <option value="Electrónica">Electrónica</option>
        <option value="Hogar">Hogar</option>
        <option value="Deportes">Deportes</option>
      </select>
      <button onclick="applyFilters()">Aplicar Filtros</button>
    `;
}

function renderProducts() {
    const productsContainer = document.getElementById("products");
    const filteredProducts = products.filter(product =>
        (filters.category === "all" || product.category === filters.category) &&
        (!filters.searchQuery || product.title.toLowerCase().includes(filters.searchQuery.toLowerCase()))
    );
    productsContainer.innerHTML = filteredProducts.map(product => `
      <div class="product-card">
        <img src="${product.image}" alt="${product.title}">
        <h3>${product.title}</h3>
        <p>${product.description}</p>
        <p class="price">${product.price}€</p>
        <button onclick="addToCart(${product.id})">Añadir al Carrito</button>
        <a href="${product.detailsUrl}" class="info-btn">Más Información</a>
      </div>
    `).join("");
}

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (product) {
        cart.push(product);
        updateCart();
    }
}

function updateCart() {
    const cartCount = document.getElementById("cartCount");
    const cartItems = document.getElementById("cartItems");
    const cartTotal = document.getElementById("cartTotal");

    cartCount.textContent = cart.length;
    cartItems.innerHTML = cart.map(item => `
      <div class="cart-item">
        <img src="${item.image}" alt="${item.title}">
        <div class="details">
          <p>${item.title}</p>
          <p>${item.price}€</p>
        </div>
        <button onclick="removeFromCart(${item.id})">Eliminar</button>
      </div>
    `).join("");

    const total = cart.reduce((sum, item) => sum + item.price, 0);
    cartTotal.textContent = total;
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    updateCart();
}

function applyFilters() {
    const categoryFilter = document.getElementById("categoryFilter").value;
    filters.category = categoryFilter;
    renderProducts();
}

function handleSearch(event) {
    filters.searchQuery = event.target.value;
    renderProducts();
}

function resetFilters() {
    filters = { category: "all", searchQuery: "" };
    document.getElementById("searchBar").value = "";
    renderProducts();
}

// Inicializar
renderFilters();
renderProducts();