const initialCart = [];

export default initialCart;