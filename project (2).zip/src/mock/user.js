const user = {
  name: "Juan Pérez",
  email: "juan.perez@example.com",
  location: "Madrid",
  memberSince: "Enero 2023",
  bio: "Amante de las gangas y los productos únicos. Vendo cosas que ya no uso y compro cosas que probablemente tampoco necesito.",
  avatar: "https://via.placeholder.com/150",
  stats: {
    productsSold: 12,
    productsBought: 8,
    rating: 4.7
  }
};

export default user;