const products = [
  {
    id: 1,
    title: "iPhone 12 Pro",
    description: "Como nuevo, con caja y accesorios",
    price: 650,
    category: "Electrónica",
    image: "https://via.placeholder.com/300",
    seller: "TechLover22",
    location: "Madrid",
    condition: "Excelente"
  },
  {
    id: 2,
    title: "Sofá de piel",
    description: "Sofá de tres plazas en perfecto estado",
    price: 350,
    category: "Hogar",
    image: "https://via.placeholder.com/300",
    seller: "HomeDecor",
    location: "Barcelona",
    condition: "Bueno"
  },
  {
    id: 3,
    title: "Bicicleta de montaña",
    description: "Bici profesional, usada solo 3 veces",
    price: 450,
    category: "Deportes",
    image: "https://via.placeholder.com/300",
    seller: "BikePro",
    location: "Valencia",
    condition: "Como nueva"
  }
];

export default products;