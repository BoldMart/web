import React from 'react';
import SearchBar from './SearchBar';
import CartButton from './CartButton';
import CategoriesDropdown from './CategoriesDropdown';

const Header = ({ 
  onSearch, 
  cartCount, 
  onCartClick,
  onProfileClick,
  categories,
  onSelectCategory,
  onHomeClick
}) => {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-10">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <button 
            onClick={onHomeClick}
            className="text-2xl font-bold text-gray-800 hover:text-gray-600 transition-colors"
          >
            ReSaleHub
          </button>
          <div className="flex items-center space-x-4">
            <CategoriesDropdown 
              categories={categories} 
              onSelectCategory={onSelectCategory} 
            />
            <SearchBar onSearch={onSearch} />
            <CartButton count={cartCount} onClick={onCartClick} />
            <button 
              onClick={onProfileClick}
              className="p-2 rounded-full hover:bg-gray-100"
            >
              <span>👤</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;