import React, { useState } from 'react';

const ProductCard = ({ product, onAddToCart }) => {
  const [isFavorite, setIsFavorite] = useState(false);

  const toggleFavorite = () => {
    setIsFavorite(!isFavorite);
  };

  const handleAddToCart = () => {
    onAddToCart(product);
  };

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300 flex flex-col h-full">
      <div className="relative flex-1">
        <img 
          src={product.image} 
          alt={product.title} 
          className="w-full h-48 object-cover"
        />
        <button 
          onClick={toggleFavorite}
          className="absolute top-2 right-2 p-2 bg-white rounded-full shadow-md"
        >
          {isFavorite ? '❤️' : '🤍'}
        </button>
      </div>
      <div className="p-4 flex flex-col flex-1">
        <h3 className="font-bold text-lg mb-1">{product.title}</h3>
        <p className="text-gray-600 text-sm mb-2 flex-1">{product.description}</p>
        <div className="flex justify-between items-center mb-2">
          <span className="font-bold text-lg">${product.price}</span>
          <span className="text-sm text-gray-500">{product.location}</span>
        </div>
        <div className="flex justify-between mb-3">
          <span className="text-xs bg-gray-100 px-2 py-1 rounded">{product.category}</span>
          <span className="text-xs bg-blue-100 px-2 py-1 rounded">{product.condition}</span>
        </div>
        <button 
          onClick={handleAddToCart}
          className="w-full bg-black text-white py-2 rounded-lg hover:bg-gray-800 transition-colors"
        >
          Añadir al carrito
        </button>
      </div>
    </div>
  );
};

export default ProductCard;