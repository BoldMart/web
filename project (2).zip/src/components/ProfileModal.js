import React from 'react';

const ProfileModal = ({ user, isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl w-full max-w-md mx-4">
        <div className="p-4 flex justify-between items-center border-b">
          <h2 className="text-xl font-bold">Mi Perfil</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            ✕
          </button>
        </div>
        
        <div className="p-6">
          <div className="flex items-center space-x-4 mb-6">
            <img 
              src={user.avatar} 
              alt={user.name} 
              className="w-16 h-16 rounded-full object-cover"
            />
            <div>
              <h3 className="font-bold text-lg">{user.name}</h3>
              <p className="text-gray-500">{user.location}</p>
              <div className="flex items-center mt-1">
                <span className="text-yellow-500">★</span>
                <span className="ml-1 text-sm font-medium">{user.stats.rating}</span>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-medium text-gray-500">Correo electrónico</h4>
              <p>{user.email}</p>
            </div>
            
            <div>
              <h4 className="text-sm font-medium text-gray-500">Miembro desde</h4>
              <p>{user.memberSince}</p>
            </div>
            
            <div>
              <h4 className="text-sm font-medium text-gray-500">Acerca de mí</h4>
              <p className="text-gray-600">{user.bio}</p>
            </div>
            
            <div className="grid grid-cols-2 gap-4 pt-4 mt-4 border-t">
              <div className="text-center">
                <p className="text-2xl font-bold">{user.stats.productsSold}</p>
                <p className="text-sm text-gray-500">Productos vendidos</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold">{user.stats.productsBought}</p>
                <p className="text-sm text-gray-500">Productos comprados</p>
              </div>
            </div>
          </div>
          
          <button className="w-full mt-6 bg-black text-white py-3 rounded-lg font-medium hover:bg-gray-800 transition-colors">
            Editar perfil
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProfileModal;