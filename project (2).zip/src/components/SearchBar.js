import React, { useState } from 'react';

const SearchBar = ({ onSearch }) => {
  const [query, setQuery] = useState('');

  const hasTypo = (text) => {
    const commonTypos = {
      'iphone': ['iphon', 'iphne', 'ipone', 'ihpone'],
      'sofá': ['sofa', 'sofá', 'soffa'],
      'bicicleta': ['bicileta', 'bicicleta', 'biciclecta']
    };
    
    for (const [correct, typos] of Object.entries(commonTypos)) {
      if (typos.some(typo => text.toLowerCase().includes(typo))) {
        return `¿Quisiste decir "${correct}"?`;
      }
    }
    return null;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (query.trim() === '') return;
    
    const typoMessage = hasTypo(query);
    if (typoMessage) {
      alert(`Por favor revisa tu búsqueda:\n\n${typoMessage}\n\nSeguiremos buscando "${query}" de todos modos.`);
    }
    
    onSearch(query);
  };

  return (
    <form onSubmit={handleSubmit} className="flex-1 max-w-md">
      <div className="relative">
        <input
          type="text"
          placeholder="Buscar productos..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent"
        />
        <button 
          type="submit"
          className="absolute right-3 top-2 text-gray-500 hover:text-gray-700"
        >
          🔍
        </button>
      </div>
    </form>
  );
};

export default SearchBar;

// DONE