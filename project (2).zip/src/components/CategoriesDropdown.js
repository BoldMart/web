import React, { useState } from 'react';

const CategoriesDropdown = ({ categories, onSelectCategory }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleSelect = (category) => {
    onSelectCategory(category);
    setIsOpen(false);
  };

  return (
    <div className="relative">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-1 px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors"
      >
        <span>📋</span>
        <span>Categorías</span>
      </button>
      
      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl z-20">
          <div className="py-1">
            <button
              onClick={() => handleSelect('all')}
              className="block w-full text-left px-4 py-2 hover:bg-gray-100"
            >
              Todas las categorías
            </button>
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => handleSelect(category)}
                className="block w-full text-left px-4 py-2 hover:bg-gray-100"
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default CategoriesDropdown;