import React, { useState, useEffect } from 'react';
import products from './mock/products';
import initialCart from './mock/cart';
import user from './mock/user';
import Header from './components/Header';
import FilterBar from './components/FilterBar';
import ProductCard from './components/ProductCard';
import CartModal from './components/CartModal';
import ProfileModal from './components/ProfileModal';

const App = () => {
  const [filteredProducts, setFilteredProducts] = useState(products);
  const [cartItems, setCartItems] = useState(initialCart);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [activeFilters, setActiveFilters] = useState({
    category: 'all',
    priceRange: 'all',
    condition: 'all',
    location: 'all'
  });

  useEffect(() => {
    const savedCart = JSON.parse(localStorage.getItem('cart')) || [];
    setCartItems(savedCart);
  }, []);

  const categories = [...new Set(products.map(product => product.category))];

  const resetFilters = () => {
    setSelectedCategory('all');
    setSearchQuery('');
    setActiveFilters({
      category: 'all',
      priceRange: 'all',
      condition: 'all',
      location: 'all'
    });
    setFilteredProducts(products);
  };

  const handleFilter = ({ 
    category = selectedCategory, 
    priceRange = activeFilters.priceRange, 
    condition = activeFilters.condition, 
    location = activeFilters.location 
  }) => {
    let result = [...products];
    const filters = { category, priceRange, condition, location };
    setActiveFilters(filters);
    
    if (category !== 'all') {
      result = result.filter(product => product.category === category);
    }
    
    if (priceRange !== 'all') {
      const [min, max] = priceRange.includes('+') 
        ? [parseInt(priceRange.replace('+', '')), Infinity]
        : priceRange.split('-').map(Number);
      
      result = result.filter(product => product.price >= min && product.price <= max);
    }
    
    if (condition !== 'all') {
      result = result.filter(product => product.condition === condition);
    }
    
    if (location !== 'all') {
      result = result.filter(product => product.location === location);
    }
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(product => 
        product.title.toLowerCase().includes(query) || 
        product.description.toLowerCase().includes(query) ||
        product.category.toLowerCase().includes(query)
      );
    }
    
    setFilteredProducts(result);
  };

  const handleSearch = (query) => {
    setSearchQuery(query);
    if (query.trim() === '') {
      handleFilter(activeFilters);
    } else {
      const result = products.filter(product => 
        product.title.toLowerCase().includes(query.toLowerCase()) || 
        product.description.toLowerCase().includes(query.toLowerCase()) ||
        product.category.toLowerCase().includes(query.toLowerCase())
      );
      setFilteredProducts(result);
    }
  };

  const handleCategorySelect = (category) => {
    setSelectedCategory(category);
    handleFilter({ category });
  };

  const handleAddToCart = (product) => {
    const updatedCart = [...cartItems, product];
    setCartItems(updatedCart);
    localStorage.setItem('cart', JSON.stringify(updatedCart));
  };

  const handleRemoveFromCart = (productId) => {
    const updatedCart = cartItems.filter(item => item.id !== productId);
    setCartItems(updatedCart);
    localStorage.setItem('cart', JSON.stringify(updatedCart));
  };

  const handleCartToggle = () => {
    setIsCartOpen(!isCartOpen);
  };

  const handleProfileToggle = () => {
    setIsProfileOpen(!isProfileOpen);
  };

  const handleHomeClick = () => {
    resetFilters();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        onSearch={handleSearch} 
        cartCount={cartItems.length} 
        onCartClick={handleCartToggle}
        onProfileClick={handleProfileToggle}
        categories={categories}
        onSelectCategory={handleCategorySelect}
        onHomeClick={handleHomeClick}
      />
      
      <main className="container mx-auto px-4 py-8">
        <FilterBar onFilter={handleFilter} categories={categories} />
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map(product => (
            <ProductCard 
              key={product.id} 
              product={product} 
              onAddToCart={handleAddToCart}
            />
          ))}
        </div>
      </main>
      
      <CartModal 
        cartItems={cartItems} 
        isOpen={isCartOpen} 
        onClose={handleCartToggle} 
        onRemoveItem={handleRemoveFromCart}
      />
      
      <ProfileModal 
        user={user} 
        isOpen={isProfileOpen} 
        onClose={handleProfileToggle}
      />
    </div>
  );
};

export default App;

// DONE